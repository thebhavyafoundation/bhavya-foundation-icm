---
type: product
id: website
title: Foundation Website
owner: Communications + Brand
status: founding
visibility: public
source:
  - _execution/wave-1/product-boundaries.md
  - _execution/wave-5/operating-model.md
  - _shared/design-system/CONTEXT.md
---

# Foundation Website

Public institutional front door for Bhavya Foundation.

**Design system**: [[../../_shared/design-system/CONTEXT.md]]  
**Boundaries**: [[../../_execution/wave-1/product-boundaries.md]]  
**Operating model**: [[../../_execution/wave-5/operating-model.md]]

## Non-goals
Not an LMS · Not Content OS · Not GitOS · Not admin dashboard

## Content policy
No fabricated statistics, projects, people, partnerships, impact, or testimonials.
Missing material uses the `bf-content-req` pattern.


## Knowledge integration

Public pages must reference KL/Content approval — see [[../../knowledge-layer/integrations/provenance-chain.md]].
