# Bhavya Website Final Export — Inventory

Generated: 2026-08-13 18:28 UTC

## Summary

- **Files:** 84
- **Total size:** 451,602 bytes (441.0 KB)
- **Checksum entries (binary):** 38

## By extension

- `.webp`: 36
- `.svg`: 20
- `.html`: 16
- `.md`: 3
- `.png`: 2
- `.js`: 2
- `(none)`: 1
- `.txt`: 1
- `.xml`: 1
- `.json`: 1
- `.css`: 1

## Asset groups

- **HTML routes:** 16
- **CSS:** 1
- **JS:** 2
- **Brand:** 1
- **Heroes:** 2
- **Missions assets:** 28
- **Knowledge assets:** 6
- **Decorative:** 7
- **Icons:** 13

## Route HTML files

- `404.html`
- `about/index.html`
- `impact/index.html`
- `index-glass-logo.html`
- `index.html`
- `knowledge/ai-lab.html`
- `knowledge/digital-institute.html`
- `missions/community.html`
- `missions/forest.html`
- `missions/heritage.html`
- `missions/index.html`
- `missions/knowledge.html`
- `participate/index.html`
- `research/index.html`
- `stories/index.html`
- `support/index.html`

## Safety

- Reference-board production usage: **0**
- Missing asset references: **0**
- Deployment: **NOT PERFORMED**
