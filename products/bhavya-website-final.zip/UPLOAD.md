# Human GitHub Sync — Bhavya Website

**Do not use GitHub Contents API for binaries.**  
**Do not create a new repository.**  
**Do not deploy from the agent.**

Target repo: https://github.com/thebhavyafoundation/bhavya-foundation-icm  
Target path: `products/website/`  
Vercel project: existing project with **Root Directory = `products/website`**

## Steps

1. **Pull latest main**
   ```bash
   cd /path/to/bhavya-foundation-icm
   git checkout main
   git pull origin main
   ```

2. **Backup current website (optional but recommended)**
   ```bash
   cp -a products/website products/website.bak-$(date +%Y%m%d)
   ```

3. **Copy export over local tree**
   ```bash
   # From the unzipped export (this folder contains products/website/)
   rsync -a --delete /path/to/bhavya-website-final/products/website/ ./products/website/
   # or:
   # rm -rf products/website && cp -a /path/to/bhavya-website-final/products/website ./products/
   ```

4. **Validate**
   ```bash
   test -f products/website/index.html
   test -f products/website/assets/brand/logo.png
   test -f products/website/assets/heroes/home-hero.webp
   test -f products/website/css/site.css
   # optional: verify checksums
   cd products/website && sha256sum -c ../../SHA256SUMS.txt 2>/dev/null || true
   ```

5. **Git status**
   ```bash
   git status
   ```

6. **Stage**
   ```bash
   git add products/website/
   ```

7. **Commit**
   ```bash
   git commit -m "feat(website): integrate bhavya mission asset system"
   ```

8. **Push**
   ```bash
   git push origin main
   ```

Vercel will pick up the push if Git is connected. Confirm Root Directory remains `products/website`.

## Package contents

- `products/website/` — complete static site
- `INVENTORY.md` — file inventory
- `SHA256SUMS.txt` — binary asset checksums
- `UPLOAD.md` — this file
